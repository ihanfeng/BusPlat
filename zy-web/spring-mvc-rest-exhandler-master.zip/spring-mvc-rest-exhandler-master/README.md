spring-mvc-rest-exhandler
=========================

Spring MVC ReST Exception Handler

Check out the two-part blog post that this example backs: [Part 1](https://stormpath.com/blog/spring-mvc-rest-exception-handling-best-practices-part-1/), [Part 2](https://stormpath.com/blog/spring-mvc-rest-exception-handling-best-practices-part-2/)
