QuadTree implementation, and application for handling cab traffic.
