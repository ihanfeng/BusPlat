public interface Func {
    public void call(QuadTree quadTree, Node node);
}
