
public class QuadTreeException extends RuntimeException {

    public QuadTreeException(String s) {
        super(s);
    }
}
