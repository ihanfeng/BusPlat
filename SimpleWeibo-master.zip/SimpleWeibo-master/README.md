# SimpleWeibo
> 基于struts2实现简易微博

### 构建工具
- Maven

### 依赖
- struts2
- mysql-jdbc
- log4j
- javax-websocket